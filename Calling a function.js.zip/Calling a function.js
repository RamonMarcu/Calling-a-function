//main.js

function sayThanks() {
  console.log('Thank you for your purchase! We appreciate your business.')
}
sayThanks();
sayThanks();
sayThanks();

//console displays:

Thank you for your purchase! We appreciate your business.
Thank you for your purchase! We appreciate your business.
Thank you for your purchase! We appreciate your business.